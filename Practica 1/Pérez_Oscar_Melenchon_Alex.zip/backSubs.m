function [x] = backSubs(A,b)


                %BACKSUBS

arraysize=size(A); %We save the array size to use it later


x=zeros(arraysize(2),1); %We create a column that will be used as the independant term


x(end)=b(end)/A(end,end);%Calculate the first unkown separatly

%This loop iterates for the rest of rows that have unkowns.
for t=arraysize(1)-1:-1:1
    
    o=A(t,1+t:arraysize(1));%%takes the matrix A and takes the vector row from pivot +1
    p=x(t+1:arraysize(1));%%takes the column of already resolved equations from the X vector

    x(t)=(b(t)-(o*p))/A(t,t);
end

end

